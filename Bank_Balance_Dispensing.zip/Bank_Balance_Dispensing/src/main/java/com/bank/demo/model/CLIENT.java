package com.bank.demo.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

@Entity
public class CLIENT {
	
	@Id
	@NotNull
	private Integer CLIENT_ID;
	private String TITLE;
	@NotNull
	private String NAME;
	private String SURNAME;
	@NotNull
	private String DOB;
	

	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CLIENT_SUB_TYPE_CODE", referencedColumnName = "CLIENT_SUB_TYPE_CODE")
    private ClientSubType ClientSubType;

	public CLIENT() {
		super();
	}
	

	public CLIENT(@NotNull Integer cLIENT_ID, String tITLE, @NotNull String nAME, String sURNAME, @NotNull String dOB,
			com.bank.demo.model.ClientSubType clientSubType) {
		super();
		CLIENT_ID = cLIENT_ID;
		TITLE = tITLE;
		NAME = nAME;
		SURNAME = sURNAME;
		DOB = dOB;
		ClientSubType = clientSubType;
	}

	
}

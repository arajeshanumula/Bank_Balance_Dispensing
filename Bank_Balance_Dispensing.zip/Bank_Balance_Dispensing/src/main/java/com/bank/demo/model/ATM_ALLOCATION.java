package com.bank.demo.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

@Entity
public class ATM_ALLOCATION {
	
	@Id
	@NotNull
	private Integer ATM_ALLOCATION_ID;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ATM_ID", referencedColumnName = "ATM_ID")
    private ATM ATM;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "DENOMINATION_ID", referencedColumnName = "DENOMINATION_ID")
    private DENOMINATION DENOMINATION;
	
	@NotNull
	private Integer COUNT;
	
	public ATM_ALLOCATION() {
		super();
	}

	public ATM_ALLOCATION(@NotNull Integer aTM_ALLOCATION_ID, com.bank.demo.model.ATM aTM,
			com.bank.demo.model.DENOMINATION dENOMINATION, @NotNull Integer cOUNT) {
		super();
		ATM_ALLOCATION_ID = aTM_ALLOCATION_ID;
		ATM = aTM;
		DENOMINATION = dENOMINATION;
		COUNT = cOUNT;
	}

	public Integer getATM_ALLOCATION_ID() {
		return ATM_ALLOCATION_ID;
	}

	public void setATM_ALLOCATION_ID(Integer aTM_ALLOCATION_ID) {
		ATM_ALLOCATION_ID = aTM_ALLOCATION_ID;
	}

	public ATM getATM() {
		return ATM;
	}

	public void setATM(ATM aTM) {
		ATM = aTM;
	}

	public DENOMINATION getDENOMINATION() {
		return DENOMINATION;
	}

	public void setDENOMINATION(DENOMINATION dENOMINATION) {
		DENOMINATION = dENOMINATION;
	}

	public Integer getCOUNT() {
		return COUNT;
	}

	public void setCOUNT(Integer cOUNT) {
		COUNT = cOUNT;
	}
	

}

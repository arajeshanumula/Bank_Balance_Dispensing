package com.bank.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bank.demo.service.IAccountTypeService;
import com.bank.demo.service.IClientAccountService;


@Controller
public class ClientAccountsController {

	@Autowired
	private IClientAccountService clientService;
	
	
	@RequestMapping(value = "/getClientAccounts")
	public String showUpdateTodoPage(@RequestParam(name="CLIENT_ID") String id, ModelMap model) {
		model.put("clientAccountDetails", clientService.getClientAccounts(id));
		model.put("currencyAccountBal", clientService.getCurrencyAccountBalances(id));
		return "clientAccountDetails";
	}
	

}

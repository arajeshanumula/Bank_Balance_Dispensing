package com.bank.demo.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

@Entity
public class CURRENCY_CONVERSION_RATE implements Serializable {

	@Id
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CURRENCY_CODE", referencedColumnName = "CURRENCY_CODE")
    private Currency Currency;
	
	@NotNull
	private String CONVERSION_INDICATOR;
	
	@NotNull
	 private Integer  RATE;
	
	public CURRENCY_CONVERSION_RATE() {
		super();
	}
	

	public CURRENCY_CONVERSION_RATE(com.bank.demo.model.Currency currency, @NotNull String cONVERSION_INDICATOR,
			@NotNull Integer rATE) {
		super();
		Currency = currency;
		CONVERSION_INDICATOR = cONVERSION_INDICATOR;
		RATE = rATE;
	}



	public Currency getCurrency() {
		return Currency;
	}

	public void setCurrency(Currency currency) {
		Currency = currency;
	}

	public String getCONVERSION_INDICATOR() {
		return CONVERSION_INDICATOR;
	}

	public void setCONVERSION_INDICATOR(String cONVERSION_INDICATOR) {
		CONVERSION_INDICATOR = cONVERSION_INDICATOR;
	}

	public Integer getRATE() {
		return RATE;
	}

	public void setRATE(Integer rATE) {
		RATE = rATE;
	}               
	  

}

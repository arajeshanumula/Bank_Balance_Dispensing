package com.bank.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="CURRENCY")
public class Currency {
	
	@Id
	@NotNull
	private String CURRENCY_CODE;
	@NotNull
	private Integer DECIMAL_PLACES;
	@NotNull
	private String DESCRIPTION;
	
	public Currency()
	{
		super();
	}
	
	public Currency(@NotNull String cURRENCY_CODE, @NotNull Integer dECIMAL_PLACES, @NotNull String dESCRIPTION) {
		super();
		CURRENCY_CODE = cURRENCY_CODE;
		DECIMAL_PLACES = dECIMAL_PLACES;
		DESCRIPTION = dESCRIPTION;
	}
	
	public String getCURRENCY_CODE() {
		return CURRENCY_CODE;
	}
	public void setCURRENCY_CODE(String cURRENCY_CODE) {
		CURRENCY_CODE = cURRENCY_CODE;
	}
	public Integer getDECIMAL_PLACES() {
		return DECIMAL_PLACES;
	}
	public void setDECIMAL_PLACES(Integer dECIMAL_PLACES) {
		DECIMAL_PLACES = dECIMAL_PLACES;
	}
	public String getDESCRIPTION() {
		return DESCRIPTION;
	}
	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}
	
	
	
	

}

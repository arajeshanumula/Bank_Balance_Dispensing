package com.bank.demo.model;

public class CurrencyAccountBalances {

	private String CLIENT_ACCOUNT_NUMBER;
	private String CURRENCY_CODE;
	private float bal;
	private String CONVERSION_INDICATOR;
	private Integer RATE;
	private float zarAmount;

	public CurrencyAccountBalances() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CurrencyAccountBalances(String cLIENT_ACCOUNT_NUMBER, String cURRENCY_CODE, float bal,
			String cONVERSION_INDICATOR, Integer rATE) {
		super();
		CLIENT_ACCOUNT_NUMBER = cLIENT_ACCOUNT_NUMBER;
		CURRENCY_CODE = cURRENCY_CODE;
		this.bal = bal;
		CONVERSION_INDICATOR = cONVERSION_INDICATOR;
		RATE = rATE;
		// this.zarAmount = zarAmount;
	}

	public String getCLIENT_ACCOUNT_NUMBER() {
		return CLIENT_ACCOUNT_NUMBER;
	}

	public void setCLIENT_ACCOUNT_NUMBER(String cLIENT_ACCOUNT_NUMBER) {
		CLIENT_ACCOUNT_NUMBER = cLIENT_ACCOUNT_NUMBER;
	}

	public String getCURRENCY_CODE() {
		return CURRENCY_CODE;
	}

	public void setCURRENCY_CODE(String cURRENCY_CODE) {
		CURRENCY_CODE = cURRENCY_CODE;
	}

	public float getBal() {
		return bal;
	}

	public void setBal(float bal) {
		this.bal = bal;
	}

	public String getCONVERSION_INDICATOR() {
		return CONVERSION_INDICATOR;
	}

	public void setCONVERSION_INDICATOR(String cONVERSION_INDICATOR) {
		CONVERSION_INDICATOR = cONVERSION_INDICATOR;
	}

	public Integer getRATE() {
		return RATE;
	}

	public void setRATE(Integer rATE) {
		RATE = rATE;
	}
	
	public float getZarAmount() {
		
		 switch(this.CONVERSION_INDICATOR){
		    case "+":
		    	zarAmount= this.getBal()  + this.RATE;
		        break;
		    case "-":
		    	zarAmount= this.getBal()  - this.RATE;
		        break;
		    case "*":
		    	zarAmount= this.getBal()  * this.RATE;
		        break;
		    case "/":
		    	zarAmount= this.getBal()  / this.RATE;
		        break;
		    default:
		    	zarAmount= 0;
		    }
		 return zarAmount;
	}

	public void setZarAmount(float zarAmount) {
		this.zarAmount = zarAmount;
	}
	  
	 

}

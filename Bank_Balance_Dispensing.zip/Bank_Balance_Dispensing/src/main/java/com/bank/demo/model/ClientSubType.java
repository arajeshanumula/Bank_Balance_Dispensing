package com.bank.demo.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "CLIENT_SUB_TYPE ")
public class ClientSubType {

	@Id
	@NotNull
	private String CLIENT_SUB_TYPE_CODE;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "client_type_code", referencedColumnName = "client_type_code")
    private ClientType clientType;
	
	@NotNull
	private String DESCRIPTION;

	public ClientSubType()
	{
		super();
	}
	
	public ClientSubType(String cLIENT_SUB_TYPE_CODE, ClientType clientType, String dESCRIPTION) {
		super();
		CLIENT_SUB_TYPE_CODE = cLIENT_SUB_TYPE_CODE;
		this.clientType = clientType;
		DESCRIPTION = dESCRIPTION;
	}



	public String getCLIENT_SUB_TYPE_CODE() {
		return CLIENT_SUB_TYPE_CODE;
	}

	public void setCLIENT_SUB_TYPE_CODE(String cLIENT_SUB_TYPE_CODE) {
		CLIENT_SUB_TYPE_CODE = cLIENT_SUB_TYPE_CODE;
	}

	public ClientType getClientType() {
		return clientType;
	}

	public void setClientType(ClientType clientType) {
		this.clientType = clientType;
	}

	public String getDESCRIPTION() {
		return DESCRIPTION;
	}

	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}
	
	
	
	
	

}

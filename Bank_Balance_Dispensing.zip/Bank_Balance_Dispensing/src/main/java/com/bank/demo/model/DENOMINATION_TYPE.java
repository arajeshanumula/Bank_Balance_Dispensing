package com.bank.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class DENOMINATION_TYPE {

	@Id
	@NotNull
	private String DENOMINATION_TYPE_CODE;
	@NotNull
	private String DESCRIPTION;
	public String getDENOMINATION_TYPE_CODE() {
		return DENOMINATION_TYPE_CODE;
	}
	public void setDENOMINATION_TYPE_CODE(String dENOMINATION_TYPE_CODE) {
		DENOMINATION_TYPE_CODE = dENOMINATION_TYPE_CODE;
	}
	public String getDESCRIPTION() {
		return DESCRIPTION;
	}
	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}
	public DENOMINATION_TYPE(@NotNull String dENOMINATION_TYPE_CODE, @NotNull String dESCRIPTION) {
		super();
		DENOMINATION_TYPE_CODE = dENOMINATION_TYPE_CODE;
		DESCRIPTION = dESCRIPTION;
	}
	
	public DENOMINATION_TYPE() {
		super();
	}
}

package com.bank.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bank.demo.service.IAccountTypeService;

@Controller
public class WelcomeController {

	@Autowired
	private IAccountTypeService accountTypeService;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String showWelcomePage(ModelMap model) {
		model.put("name", "BANK");
		model.put("accountDetails", accountTypeService.getAllAccountTypes());
		return "welcome";
	}
	
	@RequestMapping(value = "/getAcceountTypes")
	public String showTodos(ModelMap model) {
		model.put("accountDetails", accountTypeService.getAllAccountTypes());
		return "welcome";
	}

}

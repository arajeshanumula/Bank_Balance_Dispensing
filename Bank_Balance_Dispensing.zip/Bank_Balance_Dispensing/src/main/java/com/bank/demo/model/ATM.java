package com.bank.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class ATM {
	
	@Id
	@NotNull
	private Integer ATM_ID;
	
	@NotNull
	private String NAME;
	
	@NotNull
	private String LOCATION;

	public ATM(@NotNull Integer aTM_ID, @NotNull String nAME, @NotNull String lOCATION) {
		super();
		ATM_ID = aTM_ID;
		NAME = nAME;
		LOCATION = lOCATION;
	}
	
	public ATM() {
		super();
	}

	public Integer getATM_ID() {
		return ATM_ID;
	}

	public void setATM_ID(Integer aTM_ID) {
		ATM_ID = aTM_ID;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}

	public String getLOCATION() {
		return LOCATION;
	}

	public void setLOCATION(String lOCATION) {
		LOCATION = lOCATION;
	}
	
	

}

package com.bank.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.demo.model.AccountType;
import com.bank.demo.repository.AccountTypeRepository;

@Service
public class AccountTypeService implements IAccountTypeService {

	@Autowired
	private AccountTypeRepository accountTypeRepository;
	@Override
	public List<AccountType> getAllAccountTypes() {
		return accountTypeRepository.findAll();
	}

}

package com.bank.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.demo.model.ClientAccount;
import com.bank.demo.model.ClientAccountJoin;
import com.bank.demo.model.CurrencyAccountBalances;
import com.bank.demo.repository.ClientAccountRepository;

@Service
public class ClientAccountService implements IClientAccountService{
	
	@Autowired
	private ClientAccountRepository clientAccountRepository;

	@Override
	public List<ClientAccountJoin> getClientAccounts(String id) {
		return clientAccountRepository.clientAccountJoin(id);
		//return null;
	}

	@Override
	public List<CurrencyAccountBalances> getCurrencyAccountBalances(String id) {
		return clientAccountRepository.currencyAccountBal(id);
		//return null;
	}
}

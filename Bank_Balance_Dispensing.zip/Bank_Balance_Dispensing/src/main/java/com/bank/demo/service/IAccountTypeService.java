package com.bank.demo.service;

import java.util.List;

import com.bank.demo.model.AccountType;

public interface IAccountTypeService {

	List<AccountType> getAllAccountTypes();
}

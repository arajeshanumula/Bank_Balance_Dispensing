package com.bank.demo.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bank.demo.model.ClientAccount;
import com.bank.demo.model.ClientAccountJoin;
import com.bank.demo.model.CurrencyAccountBalances;

public interface ClientAccountRepository extends JpaRepository<ClientAccount, Serializable>{
	
	/*
	 * @Query("FROM ClientAccount where CLIENT_ID = ?1 order by bal  desc")
	 * //@Query(nativeQuery = true,
	 * value="SELECT ca.CLIENT_ACCOUNT_NUMBER ,ca.DISPLAY_BALANCE , AT.DESCRIPTION as ACCOUNT_TYPE_CODE  FROM CLIENT_ACCOUNT ca, ACCOUNT_TYPE AT where ca.ACCOUNT_TYPE_CODE=AT.ACCOUNT_TYPE_CODE and ca.CLIENT_ID=1 order by ca.DISPLAY_BALANCE desc"
	 * ) List<ClientAccount> getAccounts(String accNum);
	 */
	
	@Query("select new com.bank.demo.model.ClientAccountJoin(c.CLIENT_ACCOUNT_NUMBER, c.AccountType.description, c.bal) from ClientAccount c, AccountType a where c.AccountType = a and CLIENT_ID = ?1 order by c.bal desc")
	public List<ClientAccountJoin> clientAccountJoin(String accNum);
	
	@Query("select new com.bank.demo.model.CurrencyAccountBalances(c.CLIENT_ACCOUNT_NUMBER,c.Currency.CURRENCY_CODE,c.bal, a.CONVERSION_INDICATOR,a.RATE) from ClientAccount c, CURRENCY_CONVERSION_RATE a where c.Currency.CURRENCY_CODE = a and CLIENT_ID = ?1 order by c.bal desc")
	//@Query("select new com.bank.demo.model.CurrencyAccountBalances(c.CLIENT_ACCOUNT_NUMBER,c.Currency.CURRENCY_CODE,c.bal, c.Currency.CURRENCY_CONVERSION_RATE.CONVERSION_INDICATOR) from ClientAccount c, CURRENCY_CONVERSION_RATE a,Currency cr where c.Currency.CURRENCY_CODE = cr and cr.CURRENCY_CODE = a and CLIENT_ID = ?1 order by c.bal desc")
	public List<CurrencyAccountBalances> currencyAccountBal(String accNum);
	
	
}

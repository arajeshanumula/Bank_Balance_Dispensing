package com.bank.demo.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

@Entity
public class CREDIT_CARD_LIMIT implements Serializable {
	
	@Id
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CLIENT_ACCOUNT_NUMBER", referencedColumnName = "CLIENT_ACCOUNT_NUMBER")
    private ClientAccount ClientAccount;
	
	@NotNull
	private Integer ACCOUNT_LIMIT;

	public CREDIT_CARD_LIMIT(com.bank.demo.model.ClientAccount clientAccount, @NotNull Integer aCCOUNT_LIMIT) {
		super();
		ClientAccount = clientAccount;
		ACCOUNT_LIMIT = aCCOUNT_LIMIT;
	}
	
	public CREDIT_CARD_LIMIT()
	{
		super();
	}

	public ClientAccount getClientAccount() {
		return ClientAccount;
	}

	public void setClientAccount(ClientAccount clientAccount) {
		ClientAccount = clientAccount;
	}

	public Integer getACCOUNT_LIMIT() {
		return ACCOUNT_LIMIT;
	}

	public void setACCOUNT_LIMIT(Integer aCCOUNT_LIMIT) {
		ACCOUNT_LIMIT = aCCOUNT_LIMIT;
	}
	

}

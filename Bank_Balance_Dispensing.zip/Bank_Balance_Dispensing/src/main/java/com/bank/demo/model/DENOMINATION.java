package com.bank.demo.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

@Entity
public class DENOMINATION {
	
	@Id
	@NotNull
	private Integer DENOMINATION_ID;
	@NotNull
	private Integer VALUE;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "DENOMINATION_TYPE_CODE", referencedColumnName = "DENOMINATION_TYPE_CODE")
    private DENOMINATION_TYPE DENOMINATION_TYPE;
	
	public DENOMINATION() {
		super();
	}

	public DENOMINATION(@NotNull Integer dENOMINATION_ID, @NotNull Integer vALUE,
			com.bank.demo.model.DENOMINATION_TYPE dENOMINATION_TYPE) {
		super();
		DENOMINATION_ID = dENOMINATION_ID;
		VALUE = vALUE;
		DENOMINATION_TYPE = dENOMINATION_TYPE;
	}

	public Integer getDENOMINATION_ID() {
		return DENOMINATION_ID;
	}

	public void setDENOMINATION_ID(Integer dENOMINATION_ID) {
		DENOMINATION_ID = dENOMINATION_ID;
	}

	public Integer getVALUE() {
		return VALUE;
	}

	public void setVALUE(Integer vALUE) {
		VALUE = vALUE;
	}

	public DENOMINATION_TYPE getDENOMINATION_TYPE() {
		return DENOMINATION_TYPE;
	}

	public void setDENOMINATION_TYPE(DENOMINATION_TYPE dENOMINATION_TYPE) {
		DENOMINATION_TYPE = dENOMINATION_TYPE;
	}
	
	

}

package com.bank.demo.service;

import java.util.List;
import java.util.Optional;

import com.bank.demo.model.ClientAccount;
import com.bank.demo.model.ClientAccountJoin;
import com.bank.demo.model.CurrencyAccountBalances;


public interface IClientAccountService {
	
	List<ClientAccountJoin> getClientAccounts(String id);
	List<CurrencyAccountBalances> getCurrencyAccountBalances(String id);

}

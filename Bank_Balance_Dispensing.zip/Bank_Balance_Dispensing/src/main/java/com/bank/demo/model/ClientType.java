package com.bank.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "CLIENT_TYPE")
public class ClientType {

	@Id
	@NotNull
	private String client_type_code;
	@NotNull
	private String description;
	
	public ClientType(){
		super();
	}
	
	public ClientType(String client_type_code, String description) {
		super();
		this.client_type_code = client_type_code;
		this.description = description;
	}
	public String getClient_type_code() {
		return client_type_code;
	}
	public void setClient_type_code(String client_type_code) {
		this.client_type_code = client_type_code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
}

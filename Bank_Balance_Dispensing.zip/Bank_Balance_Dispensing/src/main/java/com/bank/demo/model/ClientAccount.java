package com.bank.demo.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="CLIENT_ACCOUNT ")
public class ClientAccount implements Serializable{
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CLIENT_ID", referencedColumnName = "CLIENT_ID")
    private CLIENT CLIENT;
	
	@Id
	@NotNull
	private String CLIENT_ACCOUNT_NUMBER;
	
	
	  @ManyToOne(fetch = FetchType.LAZY)
	  @JoinColumn(name = "ACCOUNT_TYPE_CODE", referencedColumnName = "ACCOUNT_TYPE_CODE") 
	  private AccountType AccountType;
	 
	/*
	 * @NotNull private String account_type_code;
	 */
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CURRENCY_CODE", referencedColumnName = "CURRENCY_CODE")
    private Currency Currency;
	
	@Column(name = "DISPLAY_BALANCE")
	@NotNull
	private float bal;
	
	public ClientAccount()
	{
		super();
	}

	public ClientAccount(com.bank.demo.model.CLIENT cLIENT, @NotNull String cLIENT_ACCOUNT_NUMBER,
			com.bank.demo.model.AccountType accountType, com.bank.demo.model.Currency currency, @NotNull float bal) {
		super();
		CLIENT = cLIENT;
		CLIENT_ACCOUNT_NUMBER = cLIENT_ACCOUNT_NUMBER;
		AccountType = accountType;
		Currency = currency;
		this.bal = bal;
	}

	public CLIENT getCLIENT() {
		return CLIENT;
	}

	public void setCLIENT(CLIENT cLIENT) {
		CLIENT = cLIENT;
	}

	public String getCLIENT_ACCOUNT_NUMBER() {
		return CLIENT_ACCOUNT_NUMBER;
	}

	public void setCLIENT_ACCOUNT_NUMBER(String cLIENT_ACCOUNT_NUMBER) {
		CLIENT_ACCOUNT_NUMBER = cLIENT_ACCOUNT_NUMBER;
	}

	public AccountType getAccountType() {
		return AccountType;
	}

	public void setAccountType(AccountType accountType) {
		AccountType = accountType;
	}

	public Currency getCurrency() {
		return Currency;
	}

	public void setCurrency(Currency currency) {
		Currency = currency;
	}

	public float getBal() {
		return bal;
	}

	public void setBal(float bal) {
		this.bal = bal;
	}

	
}

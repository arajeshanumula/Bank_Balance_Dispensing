package com.bank.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "ACCOUNT_TYPE")
public class AccountType {

	@Id
	@NotNull
	private String account_type_code;
	@NotNull
	private String description;
	@NotNull
	private String transactional;

	public AccountType() {
		super();
	}

	public AccountType(String account_Type_Code, String description, String transactional) {
		super();
		this.account_type_code = account_Type_Code;
		this.description = description;
		this.transactional = transactional;
	}

	public String getAccount_Type_Code() {
		return account_type_code;
	}

	public void setAccount_Type_Code(String account_Type_Code) {
		this.account_type_code = account_Type_Code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTransactional() {
		return transactional;
	}

	public void setTransactional(String transactional) {
		this.transactional = transactional;
	}

}

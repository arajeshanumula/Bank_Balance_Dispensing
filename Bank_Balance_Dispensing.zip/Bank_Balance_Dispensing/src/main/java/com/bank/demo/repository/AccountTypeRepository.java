package com.bank.demo.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.demo.model.AccountType;

public interface AccountTypeRepository extends JpaRepository<AccountType, Serializable>{

}

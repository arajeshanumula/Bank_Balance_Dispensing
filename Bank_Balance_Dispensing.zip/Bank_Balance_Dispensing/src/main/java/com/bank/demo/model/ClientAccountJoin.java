package com.bank.demo.model;

import java.io.Serializable;

public class ClientAccountJoin implements Serializable{

	private String CLIENT_ACCOUNT_NUMBER;
	private String description;
	private float bal;
	
	public ClientAccountJoin() {
		super();
	}

	public ClientAccountJoin(String cLIENT_ACCOUNT_NUMBER, String description, float bal) {
		super();
		CLIENT_ACCOUNT_NUMBER = cLIENT_ACCOUNT_NUMBER;
		this.description = description;
		this.bal = bal;
	}

	public String getCLIENT_ACCOUNT_NUMBER() {
		return CLIENT_ACCOUNT_NUMBER;
	}

	public void setCLIENT_ACCOUNT_NUMBER(String cLIENT_ACCOUNT_NUMBER) {
		CLIENT_ACCOUNT_NUMBER = cLIENT_ACCOUNT_NUMBER;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public float getBal() {
		return bal;
	}

	public void setBal(float bal) {
		this.bal = bal;
	}
	
	
	
}
